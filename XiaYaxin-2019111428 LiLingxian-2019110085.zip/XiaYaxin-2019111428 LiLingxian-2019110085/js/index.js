function baoyang() {
    var baoyangResult = document.getElementById("baoyangResult");
    var isGonglishu = document.getElementById("isGonglishu")
    if (isGonglishu.checked) {
        var kaigonglishu = document.getElementById("kaigonglishu").value;

        if (kaigonglishu < 20000 && kaigonglishu > 0) {

            baoyangResult.innerText = "结果:" + Math.ceil(kaigonglishu / 5000) * 200
        } else if (kaigonglishu < 100000 && kaigonglishu >= 20000) {

            baoyangResult.innerText = "结果:" + Math.ceil(kaigonglishu / 20000) * 400
        } else if (kaigonglishu >= 100000) {

            baoyangResult.innerText = "结果:" + Math.ceil(kaigonglishu / 100000) * 600
        }

    } else {

        var notGonglishu = document.getElementsByName("notGonglishu");
        for (let index = 0; index < notGonglishu.length; index++) {
            const element = notGonglishu[index];
            if (element.checked) {
                baoyangResult.innerText = "结果:" + element.value
            }
        }

    }
}

function isGonglishu() {
    var isGonglishu = document.getElementById("isGonglishu")
    var gonglishu = document.getElementsByClassName("gonglishu");
    var notGonglishu = document.getElementsByClassName("notGonglishu");
    if (isGonglishu.checked) {
        for (let index = 0; index < notGonglishu.length; index++) {
            notGonglishu[index].style.display = "none";

        }
        for (let index = 0; index < gonglishu.length; index++) {
            gonglishu[index].style.display = "";

        }
    } else {
        for (let index = 0; index < notGonglishu.length; index++) {
            notGonglishu[index].style.display = "";

        }
        for (let index = 0; index < gonglishu.length; index++) {
            gonglishu[index].style.display = "none";

        }
    }
}


function qiyou() {
    var nainlichen = document.getElementById("nainlichen").value
    var yibai_sheng = document.getElementById("yibai_sheng").value
    var qiyouType = document.getElementById("qiyouType").value

    var qiyouResult = document.getElementById("qiyouResult")

    qiyouResult.innerText = "结果:" + ((nainlichen / 100 * yibai_sheng) * qiyouType)

}

function disanzhezerenxian() {
    document.getElementById("disanzhezerenxianResult").innerText = "结果:" + document.getElementById("disanzhezerenxian").value + "元"
}

function sunshixian() {
    var chejia_sunshixian = document.getElementById("chejia_sunshixian").value
    var sunshixianResult = document.getElementById("sunshixianResult")
    sunshixianResult.innerText = "结果:" + ((chejia_sunshixian * 0.009) + 342)

}

function jiaozhizerenxian() {
    var zuoweishu = document.getElementById("zuoweishu").value
    var jiaozhizerenxianResult = document.getElementById("jiaozhizerenxianResult")
    if (zuoweishu <= 6) {
        jiaozhizerenxianResult.innerText = "结果: 950元/年"
    } else {
        jiaozhizerenxianResult.innerText = "结果: 1100元/年"
    }
}

function gouzhi() {
    var isShui = document.getElementById("isShui").value
    var gouzhijia = document.getElementById("gouzhijia").value
    var gouzhishiResult = document.getElementById("gouzhishiResult")

    if (isShui === "true") {
        gouzhishiResult.innerText = "结果:" + gouzhijia / 1.17 * 0.1
    } else {
        gouzhishiResult.innerText = "结果:" + gouzhijia * 0.1
    }
}

function daikuan() {
    var chejia = document.getElementById("chejia").value
    var shoufubili = document.getElementById("shoufubili").value
    var daikuannian = document.getElementById("daikuannian").value
    var resultDaikuan = document.getElementById("resultDaikuan")
    //首付
    var shoufu = chejia * (shoufubili / 10)

    //利息
    var li = 0.0;
    if (daikuannian === "1") {
        li = 0.04;
    } else if (daikuannian === "2") {
        li = 0.08;
    } else if (daikuannian === "3") {
        li = 0.12;
    }

    var lixi = (chejia - shoufu) * li
    var zonge = (chejia - shoufu) + lixi;
    var yuegong = zonge / (daikuannian * 12)

    resultDaikuan.innerText = "结果: 还贷总额:" + zonge + "利息:" + lixi + "月供:" + yuegong
}